var express = require("express");
var path = require("path");
var app = express();
var bodyParser = require('body-parser');
var mongoose = require('mongoose');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "./static")));
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');
mongoose.connect('mongodb://localhost/quoting_dojo');
mongoose.Promise = global.Promise;

var QuoteSchema = new mongoose.Schema({
 name: { type: String, required: true, minlength: 2},
 quote: { type: String, required: true, minlength: 2},
 updated_at: { type: Date, default: Date.now }
})
mongoose.model('Quote', QuoteSchema); // We are setting this Schema in our Models as 'User'
var Quote = mongoose.model('Quote')


app.get('/', function(req, res) {

  res.render("index");

})

app.post('/quotes', function(req, res){
  console.log("POST DATA", req.body);

  var quote = new Quote({name: req.body.name, quote: req.body.quote});

  quote.save(function(err){

    if (err) {
      console.log("something went wrong");
    } else {
      console.log('succesfully added quote!');
      res.redirect('/showQuotes');
    }

  })
})

app.get('/showQuotes', function (req, res) {
  console.log("POST DATA 2", req.body);

  Quote.find({}, function (err, quotes) {
    res.render("quotes", {data:quotes});
  }).sort({"updated_at": -1});

})




app.listen(8000, function() {
 console.log("listening on port 8000");
})
