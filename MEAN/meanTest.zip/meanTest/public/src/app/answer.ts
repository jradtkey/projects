export class Answer {

  user: string;
  answer: string;
  details: string;
  likes: number;
  questionID: string;

  constructor(user, answer, details, likes, questionID){
    this.user = name;
    this.answer = answer;
    this.details = details;
    this.likes = likes;
    this.questionID = questionID;
  }

}
