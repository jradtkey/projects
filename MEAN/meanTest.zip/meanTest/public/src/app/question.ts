export class Question {

    question: string;
    description: string;

    constructor(question, description){
      this.question = question;
      this.description = description;
    }

}
